from typing import TypedDict, Optional, List, Dict, Any # List 추가

class GraphState(TypedDict):
    """
    LangGraph 워크플로우의 상태를 정의합니다.
    """
    # 입력 데이터
    original_title: Optional[str]
    original_content: str
    processing_option: Optional[str] # 'auto' 또는 'review' (요구사항에 따라 'auto'만 우선 구현)

    # 콘텐츠 변환 관련
    transformed_title: Optional[str]
    transformed_content: Optional[str]
    
    # 사용자 검토 관련 
    user_review_feedback: Optional[str] 
    is_review_needed: bool # 기본값은 False로 설정될 수 있음

    # 포스팅 결과
    posted_url: Optional[str]
    
    # 오류 처리
    error_message: Optional[str]
    
    # 내부 상태 및 디버깅용
    current_iteration: int # 예: 검토-수정 반복 횟수
    llm_api_key_provided: bool # LLM API 키 제공 여부 (config에서 확인)
    blogger_credentials_available: bool # Blogger 인증 정보 사용 가능 여부
    
    # LLM 호출 이력 (선택적, 디버깅/로깅용)
    llm_call_history: Optional[List[Dict[str, Any]]]
    
    # Blogger API 호출 정보 (선택적, 디버깅/로깅용)
    blogger_api_call_info: Optional[Dict[str, Any]]

    # LangGraph 실행 중 발생할 수 있는 기타 중간 값들
    # 예: blog_id: Optional[str] # 포스팅할 블로그 ID (환경변수나 설정에서 가져올 수 있음)
