import logging
from fastapi import FastAPI, Request as FastAPIRequest # Request 추가
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse # HTMLResponse 추가
import pathlib # pathlib 추가

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(module)s - %(message)s",
    handlers=[
        logging.StreamHandler() # 콘솔 출력 핸들러
        # TODO: 파일 핸들러 추가 고려 (예: RotatingFileHandler)
    ]
)

logger = logging.getLogger(__name__)

app = FastAPI()

# 프로젝트 루트 디렉토리 기준 경로 설정
BASE_DIR = pathlib.Path(__file__).resolve().parent.parent 

# 정적 파일 및 템플릿 디렉토리 설정
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

@app.on_event("startup")
async def startup_event():
    logger.info("애플리케이션 시작")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("애플리케이션 종료")

@app.get("/", response_class=HTMLResponse)
async def read_index(request: FastAPIRequest):
    logger.info("루트 엔드포인트 호출됨 - index.html 렌더링")
    # 인증 콜백으로부터 전달된 메시지가 있다면 템플릿으로 전달 가능
    # 예: request.query_params.get("message")
    # 현재 script.js에서 자체적으로 쿼리 파라미터를 처리하므로, 여기서는 기본 렌더링만 수행
    return templates.TemplateResponse("index.html", {"request": request})

from app.routers import post_router # 추가
# TODO: 다른 라우터들도 필요시 추가

app.include_router(post_router.router) # post_router 등록
# TODO: 오류 처리 미들웨어 추가 고려

if __name__ == "__main__":
    import uvicorn
    logger.info("Uvicorn 서버 직접 실행 (개발용)")
    uvicorn.run(app, host="0.0.0.0", port=8000)
