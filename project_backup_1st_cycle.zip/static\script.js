document.addEventListener('DOMContentLoaded', () => {
    // 기존 UI 요소 참조
    const postTitleInput = document.getElementById('post-title');
    const postContentInput = document.getElementById('post-content');
    const submitPostButton = document.getElementById('submit-post-button');
    const statusMessageDiv = document.getElementById('status-message');
    const transformedContentDisplay = document.getElementById('transformed-content-display');
    const authBloggerButton = document.getElementById('auth-blogger-button');
    const postUrlDisplay = document.getElementById('post-url-display');
    const postUrlLink = document.getElementById('post-url-link');

    // 새로 추가된 검토 UI 요소 참조
    const reviewSection = document.getElementById('review-section');
    const reviewCommentInput = document.getElementById('review-comment-input');
    const reviseButton = document.getElementById('revise-button');
    const finalPublishButton = document.getElementById('final-publish-button');

    // 상태 저장을 위한 전역 변수 (또는 객체)
    let currentPostState = {
        original_title: null,
        original_content: null,
        transformed_title: null,
        transformed_content: null,
        processing_option: null,
        current_iteration: 0,
        is_review_needed: false // PostResponse에서 이 값을 받아 업데이트
    };

    // Blogger 인증 버튼
    if (authBloggerButton) {
        authBloggerButton.addEventListener('click', () => {
            window.location.href = '/auth/google';
        });
    }

    // "변환 및 처리 요청" 버튼
    if (submitPostButton) {
        submitPostButton.addEventListener('click', async () => {
            const title = postTitleInput.value.trim();
            const content = postContentInput.value.trim();
            const processingOptionRadio = document.querySelector('input[name="processing-option"]:checked');
            
            if (!processingOptionRadio) {
                showStatusMessage('처리 옵션을 선택해주세요.', 'danger');
                return;
            }
            const processingOption = processingOptionRadio.value;

            if (!content) { // 제목은 선택 사항일 수 있으나, 내용은 필수
                showStatusMessage('내용을 입력해주세요.', 'danger');
                return;
            }

            showStatusMessage('처리 중...', 'info', false);
            transformedContentDisplay.value = '';
            hidePostUrl();
            hideReviewSection(); // 검토 섹션도 초기에는 숨김

            currentPostState = { // 상태 초기화
                original_title: title,
                original_content: content,
                transformed_title: null,
                transformed_content: null,
                processing_option: processingOption,
                current_iteration: 0,
                is_review_needed: false
            };

            try {
                const response = await fetch('/process_post', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        title: title,
                        content: content,
                        processing_option: processingOption,
                    }),
                });

                const result = await response.json(); // PostResponse 예상
                console.log("Full server response (result object):", JSON.stringify(result, null, 2)); // 전체 응답 객체 출력
                console.log("Value of result.posted_url:", result.posted_url);
                console.log("Type of result.posted_url:", typeof result.posted_url);

                if (response.ok && !result.error_detail) {
                    showStatusMessage(result.message || '처리가 완료되었습니다.', 'success');
                    
                    // 상태 업데이트
                    currentPostState.transformed_title = result.transformed_title;
                    currentPostState.transformed_content = result.transformed_content;
                    // PostResponse에 is_review_needed와 current_iteration이 있다고 가정
                    // (실제로는 PostResponse 모델에 이 필드들이 추가되어야 함)
                    currentPostState.is_review_needed = result.is_review_needed !== undefined ? result.is_review_needed : (processingOption === 'review' && !result.posted_url);
                    currentPostState.current_iteration = result.current_iteration !== undefined ? result.current_iteration : 0;

                    if (result.transformed_content) {
                        transformedContentDisplay.value = result.transformed_content;
                    }

                    if (result.posted_url) { // 자동 개시 성공
                        showStatusMessage(`Blogger에 성공적으로 게시되었습니다! URL: ${result.posted_url}`, 'success', false); // result.posted_url로 수정됨 (이전 수정 반영)
                        showPostUrl(result.posted_url); // result.posted_url로 수정됨 (이전 수정 반영)
                        hideReviewSection();
                    } else if (currentPostState.is_review_needed && processingOption === 'review') {
                        // 검토 필요 상태 (is_review_needed가 true이고, 아직 포스팅 URL이 없는 경우)
                        showReviewSection();
                    } else if (result.error_detail) { // 명시적 에러는 아니지만, 결과가 이상할 때
                         showStatusMessage(result.message || '처리 중 문제가 발생했습니다.', 'warning');
                    }

                } else {
                    showStatusMessage(result.error_detail || result.message || '오류가 발생했습니다.', 'danger');
                    transformedContentDisplay.value = result.transformed_content || ''; // 오류 시에도 변환된 내용이 있다면 표시
                }
            } catch (error) {
                console.error('Error submitting post:', error);
                showStatusMessage('요청 처리 중 오류가 발생했습니다. 콘솔을 확인해주세요.', 'danger');
            }
        });
    }

    // "의견 반영하여 재처리" 버튼
    if (reviseButton) {
        reviseButton.addEventListener('click', async () => {
            const comment = reviewCommentInput.value.trim();
            // 의견 없이도 재처리 요청은 가능 (서버에서 무시하거나, 현재 내용으로 재검토 요청)

            showStatusMessage('의견 반영하여 재처리 중...', 'info', false);
            hidePostUrl();

            try {
                // ReviewRequest 모델에 맞게 payload 구성
                // content_service.py의 process_review는 ReviewRequest만 받음.
                // 그러나 GraphState를 재구성하려면 추가 정보가 필요함.
                // 이 정보는 currentPostState에 저장된 값을 사용.
                // 서버 API는 ReviewRequest 모델만 받으므로, 서버 측에서 이 상태를 어떻게든 알아야 함.
                // 현재 content_service.py의 process_review는 임시로 GraphState를 구성하고 있음.
                // 이 부분을 일치시키기 위해, 클라이언트는 ReviewRequest 외의 정보는
                // 다른 방식으로 전달하거나 (예: 세션, 또는 서버가 이전 상태를 기억),
                // ReviewRequest 모델 자체를 확장해야 함.
                // 여기서는 ReviewRequest 모델에 comment와 final_publish만 보내고,
                // 서버(content_service)가 currentPostState에 해당하는 정보를
                // 어떻게든 (예: 이전 요청의 응답을 통해 클라이언트가 다시 보내는 방식 - 지금은 구현 안됨)
                // 가지고 있다고 가정하고 진행.
                // **이 부분은 실제 작동을 위해 서버-클라이언트 간 상태 전달 방식에 대한 명확한 정의가 필요합니다.**

                const payload = { // ReviewRequest 모델에 맞춤
                    comment: comment,
                    final_publish: false
                    // 여기에 currentPostState의 다른 정보들을 추가로 보내야 서버가 GraphState를 올바로 구성 가능
                    // 예: ...currentPostState (단, ReviewRequest 모델이 이를 받아야 함)
                };
                
                // 임시: 서버가 currentPostState를 알아야 하므로, 필요한 정보를 함께 보낸다고 가정하고
                // 서버의 process_review 함수가 이를 처리하도록 수정했다고 가정.
                // (실제로는 ReviewRequest 모델을 확장하거나, API endpoint가 추가 정보를 받아야 함)
                const fullPayloadForServer = {
                    ...payload, // comment, final_publish
                    // 아래는 GraphState 재구성을 위해 서버에 전달해야 할 수 있는 정보들
                    // (현재 ReviewRequest 모델에는 없지만, content_service.py의 process_review에서 임시로 사용 중)
                    original_title: currentPostState.original_title,
                    original_content: currentPostState.original_content,
                    transformed_title: currentPostState.transformed_title,
                    transformed_content: currentPostState.transformed_content,
                    processing_option: currentPostState.processing_option,
                    current_iteration: currentPostState.current_iteration
                };

                const response = await fetch('/submit_review', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(fullPayloadForServer), // 서버가 받을 수 있도록 확장된 payload
                });
                const result = await response.json();

                if (response.ok && !result.error_detail) {
                    showStatusMessage(result.message || '의견이 반영되어 재처리되었습니다. 다시 검토해주세요.', 'success');
                    
                    currentPostState.transformed_title = result.transformed_title;
                    currentPostState.transformed_content = result.transformed_content;
                    currentPostState.is_review_needed = result.is_review_needed !== undefined ? result.is_review_needed : true;
                    currentPostState.current_iteration = result.current_iteration !== undefined ? result.current_iteration : (currentPostState.current_iteration + 1);

                    transformedContentDisplay.value = result.transformed_content || '';
                    reviewCommentInput.value = ''; 
                    showReviewSection(); 
                } else {
                    showStatusMessage(result.error_detail || result.message || '재처리 중 오류가 발생했습니다.', 'danger');
                }
            } catch (error) {
                console.error('Error revising content:', error);
                showStatusMessage('재처리 요청 중 오류가 발생했습니다. 콘솔을 확인해주세요.', 'danger');
            }
        });
    }

    // "최종 배포 승인" 버튼
    if (finalPublishButton) {
        finalPublishButton.addEventListener('click', async () => {
            const comment = reviewCommentInput.value.trim(); 

            showStatusMessage('최종 배포 중...', 'info', false);
            hidePostUrl();

            try {
                const payload = { // ReviewRequest 모델에 맞춤
                    comment: comment, 
                    final_publish: true
                };
                const fullPayloadForServer = {
                    ...payload,
                    original_title: currentPostState.original_title,
                    original_content: currentPostState.original_content,
                    transformed_title: currentPostState.transformed_title,
                    transformed_content: currentPostState.transformed_content,
                    processing_option: currentPostState.processing_option,
                    current_iteration: currentPostState.current_iteration
                };

                const response = await fetch('/submit_review', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(fullPayloadForServer),
                });
                const result = await response.json();

                if (response.ok && result.posted_url && !result.error_detail) {
                    // 이미 showStatusMessage에 posted_url이 포함되도록 수정했으므로, result.message는 사용하지 않음
                    showStatusMessage(`Blogger에 성공적으로 게시되었습니다! URL: ${result.posted_url}`, 'success', false);
                    transformedContentDisplay.value = result.transformed_content || ''; 
                    showPostUrl(result.posted_url);
                    hideReviewSection();
                    reviewCommentInput.value = '';
                } else {
                    showStatusMessage(result.error_detail || result.message || '최종 배포 중 오류가 발생했습니다.', 'danger');
                }
            } catch (error) {
                console.error('Error finalizing post:', error);
                showStatusMessage('최종 배포 요청 중 오류가 발생했습니다. 콘솔을 확인해주세요.', 'danger');
            }
        });
    }

    function showStatusMessage(message, type = 'info', autoHide = true) {
        console.log("showStatusMessage called with:", message, type, autoHide); // 디버깅 로그 추가
        if (statusMessageDiv) {
            statusMessageDiv.textContent = message;
            statusMessageDiv.className = `alert alert-${type} mt-3`;
            statusMessageDiv.style.display = 'block';
            if (autoHide) {
                setTimeout(() => {
                    if (statusMessageDiv.style.display !== 'none') {
                        statusMessageDiv.style.display = 'none';
                    }
                }, 5000);
            }
        }
    }
    
    function showPostUrl(url) {
        console.log("showPostUrl called with URL:", url); // 디버깅 로그 추가
        if (postUrlDisplay && postUrlLink) {
            postUrlLink.href = url;
            postUrlLink.textContent = url;
            postUrlDisplay.style.display = 'block';
        }
    }

    function hidePostUrl() {
        if (postUrlDisplay) {
            postUrlDisplay.style.display = 'none';
        }
    }

    function showReviewSection() {
        if (reviewSection) {
            reviewSection.style.display = 'block';
        }
    }

    function hideReviewSection() {
        if (reviewSection) {
            reviewSection.style.display = 'none';
        }
    }

    const urlParams = new URLSearchParams(window.location.search);
    const authError = urlParams.get('auth_error');
    const authSuccess = urlParams.get('auth_success');
    const generalMessage = urlParams.get('message');

    if (generalMessage) {
        const messageType = urlParams.get('message_type') || 'info';
        showStatusMessage(decodeURIComponent(generalMessage), messageType, !authError && !authSuccess);
    }
    if (authError && !generalMessage) {
        let errorMessage = "Blogger 인증에 실패했습니다.";
        if (authError === 'no_code') errorMessage = "Blogger 인증 콜백에서 코드를 받지 못했습니다.";
        else if (authError === 'callback_failed') errorMessage = "Blogger 인증 콜백 처리 중 오류가 발생했습니다.";
        showStatusMessage(errorMessage, 'danger', false);
    } else if (authSuccess && !generalMessage) {
        showStatusMessage("Blogger 인증이 성공적으로 완료되었습니다!", 'success');
    }
    
    if (authError || authSuccess || generalMessage) {
        window.history.replaceState({}, document.title, window.location.pathname);
    }
});
