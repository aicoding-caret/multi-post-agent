import logging
from langgraph.graph import StateGraph # StateGraph로 변경하고, langgraph.graph에서 가져옴
from langgraph.graph import END # langgraph.graph에서 END 가져오도록 변경
from app.graph.state import GraphState
from app.graph.nodes import (
    transform_content_node,
    post_to_blogger_node,
    should_post_or_review_node,
    request_user_review_node,
    revise_content_node,
    should_revise_or_post_final_node
)

logger = logging.getLogger(__name__)

_compiled_graph = None

def get_compiled_graph():
    """
    컴파일된 LangGraph 워크플로우 그래프를 반환합니다.
    이미 생성된 경우 기존 인스턴스를 반환하고, 없으면 새로 생성합니다.
    """
    global _compiled_graph
    if _compiled_graph is None:
        logger.info("컴파일된 그래프가 없어 새로 생성합니다.")
        # StatefulGraph를 사용하던 부분을 일반 Graph로 변경하고, 상태 타입을 명시합니다.
        # LangGraph 최신 버전에서는 Graph(StateGraph)를 더 권장하는 추세일 수 있습니다.
        # 하지만 StatefulGraph가 여전히 유효하다면 그대로 사용합니다.
        # 오류 메시지가 'StatefulGraph'를 찾을 수 없다고 했으므로,
        # 일단은 이 부분이 문제의 핵심일 가능성이 높습니다.
        # 만약 StatefulGraph가 정말로 langgraph.graph에 없다면,
        # from langgraph.graphs import StateGraph 와 같이 다른 경로를 찾아야 합니다.
        # 또는 from langgraph.graph.graph import StatefulGraph 와 같이 더 구체적인 경로일 수 있습니다.

        # 현재 오류는 "cannot import name 'StatefulGraph' from 'langgraph.graph'" 이므로,
        # StatefulGraph의 임포트 경로가 문제일 가능성이 큽니다.
        # langgraph.graph 모듈 자체는 찾지만, 그 안에 StatefulGraph가 없다는 의미입니다.

        # LangGraph의 버전에 따라 StateGraph 또는 Graph를 사용하고,
        # 상태를 명시적으로 다루는 방식으로 API가 변경되었을 수 있습니다.
        # 예: workflow = Graph() # 또는 StateGraph(GraphState)

        # 일단은 기존 코드를 최대한 유지하되, 오류 메시지에 집중합니다.
        # "cannot import name 'StatefulGraph' from 'langgraph.graph'"
        # 이 오류는 StatefulGraph의 위치 문제입니다. END는 다음 문제일 수 있습니다.

        # 다시 한번 확인: langgraph.graph.StateGraph 가 정확한 경로일 수 있습니다.
        # 또는 langgraph.graphs.StateGraph (s가 붙음)
        # 문서를 찾아보니 langgraph.graph.StateGraph 가 더 일반적인 것 같습니다.
        # 하지만 원래 코드에서 StatefulGraph를 사용했으므로, 이를 먼저 시도합니다.

        # 위에서 StateGraph를 직접 임포트하도록 변경했으므로, 이 try-except 블록은 더 이상 필요하지 않습니다.
        # from langgraph.graph import StateGraph # 이미 상단에서 임포트

        workflow = StateGraph(GraphState) # StatefulGraph를 StateGraph로 변경

        workflow.add_node("transform_content", transform_content_node)
        logger.info("노드 추가: transform_content")
        workflow.add_node("post_to_blogger", post_to_blogger_node)
        logger.info("노드 추가: post_to_blogger")
        workflow.add_node("request_user_review", request_user_review_node)
        logger.info("노드 추가: request_user_review")
        workflow.add_node("revise_content", revise_content_node)
        logger.info("노드 추가: revise_content")

        workflow.set_entry_point("transform_content")
        logger.info("진입점 설정: transform_content")

        workflow.add_conditional_edges(
            "transform_content",
            should_post_or_review_node,
            {
                "post_to_blogger": "post_to_blogger",
                "request_user_review": "request_user_review",
                "end": END
            }
        )
        logger.info("조건부 엣지 추가: transform_content -> should_post_or_review_node")

        # request_user_review 노드 이후에는 바로 END로 가서 중간 결과를 반환하도록 수정
        # should_revise_or_post_final_node로 가는 조건부 엣지는 /submit_review 요청 시 process_review 함수 내에서
        # 그래프를 특정 노드부터 시작하거나, 해당 조건부 함수를 직접 호출하는 방식으로 처리해야 함.
        # 우선 /process_post 요청 시 발생하는 무한 루프를 막기 위해 아래와 같이 변경.
        workflow.add_edge("request_user_review", END)
        logger.info("엣지 추가: request_user_review -> END (사용자 검토를 위해 일단 종료)")

        # revise_content는 request_user_review를 다시 호출하는 것이 아니라,
        # 수정된 내용을 다시 검토하도록 request_user_review로 가는 것이 맞음.
        # 하지만 request_user_review가 END로 가므로, 이 엣지도 재검토 필요.
        # 우선은 이 엣지는 유지하되, 전체적인 흐름 재설계가 필요함을 인지.
        workflow.add_edge("revise_content", "request_user_review")
        logger.info("엣지 추가: revise_content -> request_user_review")

        workflow.add_edge("post_to_blogger", END)
        logger.info("엣지 추가: post_to_blogger -> END")
        
        try:
            _compiled_graph = workflow.compile() # recursion_limit 제거
            logger.info("LangGraph 그래프 컴파일 성공")
        except Exception as e:
            logger.error(f"LangGraph 그래프 컴파일 실패: {e}")
            _compiled_graph = None 
            raise
            
    return _compiled_graph

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    logger.info("--- LangGraph Builder 직접 실행 테스트 시작 ---")
    try:
        test_graph = get_compiled_graph()
        if test_graph:
            logger.info(f"테스트 그래프 생성 및 컴파일 성공: {test_graph}")
            from app.core.config import settings
            if settings.LLM_API_KEY and settings.LLM_API_KEY != "YOUR_LLM_API_KEY" and "sk-" in settings.LLM_API_KEY \
               and settings.BLOG_ID and settings.BLOG_ID != "YOUR_BLOG_ID":
                logger.info("LLM API 키 및 BLOG_ID 확인됨. 'auto' 옵션 그래프 실행 테스트 시작...")
                initial_state_auto = GraphState(
                    original_title="LangGraph 자동 개시 테스트",
                    original_content="이것은 LangGraph의 '자동 개시' 옵션을 테스트하는 글입니다.",
                    processing_option="auto",
                    transformed_title=None, transformed_content=None, user_review_feedback=None,
                    is_review_needed=False, posted_url=None, error_message=None, current_iteration=0,
                    llm_api_key_provided=True, blogger_credentials_available=True,
                    llm_call_history=[], blogger_api_call_info={}
                )
                if settings.GOOGLE_CLIENT_ID != "YOUR_GOOGLE_CLIENT_ID":
                    from app.services import blogger_service
                    if "default_user" not in blogger_service.temp_credentials_storage:
                        logger.info("테스트를 위해 임시 Blogger 인증 정보를 설정합니다 (auto).")
                        blogger_service.temp_credentials_storage["default_user"] = {
                            "token": "fake_token_for_testing", "refresh_token": "fake_refresh_token_for_testing",
                            "token_uri": "https://oauth2.googleapis.com/token", "client_id": settings.GOOGLE_CLIENT_ID,
                            "client_secret": settings.GOOGLE_CLIENT_SECRET, "scopes": ["https://www.googleapis.com/auth/blogger"]
                        }
                final_state_auto = test_graph.invoke(initial_state_auto)
                logger.info(f"--- 'auto' 옵션 테스트 결과: {final_state_auto}")

                logger.info("'review' 옵션 그래프 실행 테스트 시작 (1차 검토 요청까지)...")
                initial_state_review = GraphState(
                    original_title="LangGraph 검토 후 개시 테스트",
                    original_content="이것은 LangGraph의 '검토 후 개시' 옵션을 테스트하는 글입니다. 1차 변환 후 검토가 요청되어야 합니다.",
                    processing_option="review",
                    transformed_title=None, transformed_content=None, user_review_feedback=None,
                    is_review_needed=False, posted_url=None, error_message=None, current_iteration=0,
                    llm_api_key_provided=True, blogger_credentials_available=True,
                    llm_call_history=[], blogger_api_call_info={}
                )
                if settings.GOOGLE_CLIENT_ID != "YOUR_GOOGLE_CLIENT_ID":
                    from app.services import blogger_service
                    if "default_user" not in blogger_service.temp_credentials_storage:
                        logger.info("테스트를 위해 임시 Blogger 인증 정보를 설정합니다 (review).")
                        blogger_service.temp_credentials_storage["default_user"] = {
                            "token": "fake_token_for_testing", "refresh_token": "fake_refresh_token_for_testing",
                            "token_uri": "https://oauth2.googleapis.com/token", "client_id": settings.GOOGLE_CLIENT_ID,
                            "client_secret": settings.GOOGLE_CLIENT_SECRET, "scopes": ["https://www.googleapis.com/auth/blogger"]
                        }
                state_after_initial_transform = test_graph.invoke(initial_state_review)
                logger.info(f"--- 'review' 옵션 1단계 결과 (검토 요청): {state_after_initial_transform}")
                assert state_after_initial_transform.get("is_review_needed") is True
                assert state_after_initial_transform.get("transformed_content") is not None

                logger.info("'review' 옵션 - 사용자 의견 제출 테스트...")
                state_with_feedback = state_after_initial_transform.copy()
                state_with_feedback["user_review_feedback"] = "조금 더 친근한 말투로 바꿔주세요."
                state_after_revision = test_graph.invoke(state_with_feedback)
                logger.info(f"--- 'review' 옵션 2단계 결과 (의견 반영 후 재검토 요청): {state_after_revision}")
                assert state_after_revision.get("is_review_needed") is True
                assert state_after_revision.get("user_review_feedback") is None
                assert state_after_revision.get("transformed_content") != state_after_initial_transform.get("transformed_content")

                logger.info("'review' 옵션 - 최종 배포 테스트...")
                state_for_final_post = state_after_revision.copy()
                state_for_final_post["is_review_needed"] = False
                final_state_review = test_graph.invoke(state_for_final_post)
                logger.info(f"--- 'review' 옵션 3단계 결과 (최종 포스팅): {final_state_review}")
                assert final_state_review.get("posted_url") is not None or final_state_review.get("error_message") is not None
            else:
                logger.warning("테스트 실행 건너뜀: LLM_API_KEY 또는 BLOG_ID가 유효하게 설정되지 않음.")
        else:
            logger.error("테스트 그래프 생성 실패.")
    except Exception as e:
        logger.error(f"builder.py 직접 실행 중 오류 발생: {e}", exc_info=True)
    logger.info("--- LangGraph Builder 직접 실행 테스트 종료 ---")
