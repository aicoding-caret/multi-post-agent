import logging
from app.graph.state import GraphState
from app.core.config import settings # API 키 접근
from fastapi import HTTPException # Blogger 서비스 호출 시 발생할 수 있는 예외 처리용

# Gemini 사용 시
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

logger = logging.getLogger(__name__)

def get_llm_client():
    """LLM 클라이언트를 반환합니다. API 키가 없으면 None을 반환합니다."""
    # .env 파일에서 GEMINI_API_KEY를 사용하도록 settings.GEMINI_API_KEY로 변경
    if settings.GEMINI_API_KEY and settings.GEMINI_API_KEY != "YOUR_GEMINI_API_KEY_HERE": 
        try:
            # 모델명은 필요에 따라 변경 가능 (예: "gemini-pro", "gemini-1.5-flash" 등)
            # ChatGoogleGenerativeAI로 변경하고, google_api_key 파라미터 사용
            client = ChatGoogleGenerativeAI(model="gemini-2.5-flash-preview-05-20", google_api_key=settings.GEMINI_API_KEY, temperature=0.7, convert_system_message_to_human=True)
            logger.info(f"ChatGoogleGenerativeAI 클라이언트 생성 성공 (모델: gemini-2.5-flash-preview-05-20)")
            return client
        except Exception as e:
            logger.error(f"ChatGoogleGenerativeAI 클라이언트 생성 실패: {e}")
            return None
    else:
        logger.warning("GEMINI_API_KEY가 유효하게 설정되지 않았습니다. LLM 기능이 제한됩니다.")
        return None

def transform_content_node(state: GraphState) -> GraphState:
    """
    입력된 원본 콘텐츠를 LLM을 사용하여 변환합니다.
    """
    logger.info("--- transform_content_node 실행 시작 ---")
    
    original_content = state.get("original_content")
    original_title = state.get("original_title", "") # 기본값 빈 문자열로 설정

    # 상태 초기화 (오류 메시지 등)
    state["error_message"] = None
    state["transformed_content"] = None
    state["transformed_title"] = None # 제목 변환도 고려 시
    state["is_review_needed"] = False # 기본적으로 검토 불필요로 초기화

    if not original_content:
        logger.error("변환할 원본 콘텐츠가 없습니다.")
        state["error_message"] = "변환할 원본 콘텐츠가 없습니다."
        return state

    llm = get_llm_client()
    if not llm:
        logger.error("Gemini 클라이언트를 초기화할 수 없습니다. API 키를 확인하세요.") # Gemini로 변경
        state["error_message"] = "Gemini 서비스에 연결할 수 없습니다. API 키 설정을 확인해주세요." # Gemini로 변경
        state["transformed_content"] = f"원본 내용: {original_content}"
        state["transformed_title"] = f"원본 제목: {original_title}"
        state["llm_api_key_provided"] = False
        logger.info("--- transform_content_node 실행 종료 (LLM 미연결) ---")
        return state
    
    state["llm_api_key_provided"] = True

    prompt_template_str = """주어진 텍스트를 기반으로 전문적이고 정중한 스타일의 블로그 게시물을 작성해주세요.
결과는 HTML 형식이어야 하며, 제목은 `<h3>` 태그로, 본문은 여러 개의 `<p>` 태그로 구성해주세요.
만약 원본 제목이 제공되지 않았다면, 내용에 어울리는 제목을 생성해주세요.

[원본 데이터]
제목: {title}
내용: {text}

[변환된 블로그 게시물 HTML]
"""
    
    prompt = ChatPromptTemplate.from_template(prompt_template_str)
    output_parser = StrOutputParser()
    chain = prompt | llm | output_parser

    try:
        logger.info(f"LLM 호출 시작. 원본 제목: '{original_title}', 원본 내용 길이: {len(original_content)}")
        transformed_html_output = chain.invoke({"title": original_title, "text": original_content})

        # LLM 응답에서 머리말 및 마크다운 코드 블록 제거
        # "```html" 이전의 모든 내용을 제거
        if "```html" in transformed_html_output:
            transformed_html_output = transformed_html_output.split("```html", 1)[-1]
        # 마지막 "```" 제거
        if transformed_html_output.strip().endswith("```"):
            transformed_html_output = transformed_html_output.rsplit("```", 1)[0]
        transformed_html_output = transformed_html_output.strip()
        
        parsed_title = original_title 
        # 제목 파싱 로직 (이전과 동일)
        if "<h3>" in transformed_html_output and "</h3>" in transformed_html_output:
            start_idx = transformed_html_output.find("<h3>") + len("<h3>")
            end_idx = transformed_html_output.find("</h3>", start_idx)
            if start_idx < end_idx:
                parsed_title = transformed_html_output[start_idx:end_idx].strip()

        state["transformed_content"] = transformed_html_output 
        state["transformed_title"] = parsed_title
        logger.info(f"LLM을 통한 콘텐츠 변환 성공. 변환된 제목: '{parsed_title}', 변환된 내용 길이: {len(transformed_html_output)}")

    except Exception as e:
        logger.error(f"LLM 호출 중 오류 발생: {e}")
        state["error_message"] = f"콘텐츠 변환 중 오류가 발생했습니다: {str(e)}"
        state["transformed_content"] = f"오류 발생 - 원본 내용: {original_content}"
        state["transformed_title"] = f"오류 발생 - 원본 제목: {original_title}"
        
    if state.get("llm_call_history") is None:
        state["llm_call_history"] = []
    state["llm_call_history"].append({
        "node": "transform_content_node",
        "input_title": original_title,
        "input_content_length": len(original_content),
        "output_title": state.get("transformed_title"),
        "output_content_length": len(state.get("transformed_content","")),
        "error": state.get("error_message")
    })
    logger.info("--- transform_content_node 실행 완료 ---")
    return state

def request_user_review_node(state: GraphState) -> GraphState:
    """
    사용자에게 변환된 콘텐츠 검토를 요청합니다.
    GraphState의 is_review_needed를 True로 설정합니다.
    """
    logger.info("--- request_user_review_node 실행 시작 ---")
    transformed_content = state.get("transformed_content")
    transformed_title = state.get("transformed_title")

    if not transformed_content:
        logger.warning("검토 요청할 변환된 콘텐츠가 없습니다.")
    state["is_review_needed"] = True
    logger.info(f"사용자 검토 요청 설정 완료. 변환된 제목: '{transformed_title}', 검토 필요: {state['is_review_needed']}")
    logger.info("--- request_user_review_node 실행 완료 ---")
    return state

def revise_content_node(state: GraphState) -> GraphState:
    """
    사용자 의견을 반영하여 LLM으로 콘텐츠를 재변환합니다.
    """
    logger.info("--- revise_content_node 실행 시작 ---")
    current_transformed_content = state.get("transformed_content")
    user_comment = state.get("user_review_feedback")

    if not current_transformed_content:
        logger.error("수정할 변환된 콘텐츠가 없습니다.")
        state["error_message"] = "수정할 변환된 콘텐츠가 없습니다."
        logger.info("--- revise_content_node 실행 종료 (콘텐츠 없음) ---")
        return state

    if not user_comment:
        logger.warning("사용자 의견이 없습니다. 콘텐츠를 수정하지 않습니다.")
        logger.info("--- revise_content_node 실행 종료 (사용자 의견 없음) ---")
        return state

    llm = get_llm_client()
    if not llm:
        logger.error("Gemini 클라이언트를 초기화할 수 없습니다. API 키를 확인하세요.") # Gemini로 변경
        state["error_message"] = "Gemini 서비스에 연결할 수 없습니다. API 키 설정을 확인해주세요." # Gemini로 변경
        logger.info("--- revise_content_node 실행 종료 (LLM 미연결) ---")
        return state

    prompt_template_str = """다음 텍스트를 사용자 의견을 반영하여 수정하고, 전체적인 문맥과 어울리도록 자연스럽게 다듬어주세요.
결과는 이전과 동일하게 HTML 형식이어야 하며, 제목은 `<h3>` 태그로, 본문은 여러 개의 `<p>` 태그로 구성해주세요.

[기존 텍스트 (HTML)]
{text}

[사용자 의견]
{comment}

[수정된 블로그 게시물 HTML]
"""
    prompt = ChatPromptTemplate.from_template(prompt_template_str)
    output_parser = StrOutputParser()
    chain = prompt | llm | output_parser

    try:
        logger.info(f"LLM 호출 시작 (콘텐츠 수정). 사용자 의견: '{user_comment}'")
        revised_html_output = chain.invoke({"text": current_transformed_content, "comment": user_comment})

        # LLM 응답에서 머리말 및 마크다운 코드 블록 제거
        # "```html" 이전의 모든 내용을 제거
        if "```html" in revised_html_output:
            revised_html_output = revised_html_output.split("```html", 1)[-1]
        # 마지막 "```" 제거
        if revised_html_output.strip().endswith("```"):
            revised_html_output = revised_html_output.rsplit("```", 1)[0]
        revised_html_output = revised_html_output.strip()
        
        revised_title = state.get("transformed_title", "")
        # 제목 파싱 로직 (이전과 동일)
        if "<h3>" in revised_html_output and "</h3>" in revised_html_output:
            start_idx = revised_html_output.find("<h3>") + len("<h3>")
            end_idx = revised_html_output.find("</h3>", start_idx)
            if start_idx < end_idx:
                revised_title = revised_html_output[start_idx:end_idx].strip()

        state["transformed_content"] = revised_html_output
        state["transformed_title"] = revised_title
        state["user_review_feedback"] = None 
        state["is_review_needed"] = True 
        state["error_message"] = None
        logger.info(f"LLM을 통한 콘텐츠 수정 성공. 수정된 제목: '{revised_title}', 수정된 내용 길이: {len(revised_html_output)}")

    except Exception as e:
        logger.error(f"LLM 호출 중 오류 발생 (콘텐츠 수정): {e}")
        state["error_message"] = f"콘텐츠 수정 중 오류가 발생했습니다: {str(e)}"

    if state.get("llm_call_history") is None:
        state["llm_call_history"] = []
    state["llm_call_history"].append({
        "node": "revise_content_node",
        "input_content_length": len(current_transformed_content or ""),
        "user_comment": user_comment,
        "output_title": state.get("transformed_title"),
        "output_content_length": len(state.get("transformed_content","")),
        "error": state.get("error_message")
    })
    logger.info("--- revise_content_node 실행 완료 ---")
    return state

def post_to_blogger_node(state: GraphState) -> GraphState:
    """
    변환된 콘텐츠를 Blogger에 포스팅합니다.
    """
    logger.info("--- post_to_blogger_node 실행 시작 ---")
    state["error_message"] = None
    state["posted_url"] = None
    transformed_content = state.get("transformed_content")
    title_to_post = state.get("transformed_title") or state.get("original_title", "제목 없음")

    if not transformed_content:
        logger.error("Blogger에 포스팅할 콘텐츠가 없습니다.")
        state["error_message"] = "Blogger에 포스팅할 콘텐츠가 없습니다."
        logger.info("--- post_to_blogger_node 실행 종료 (콘텐츠 없음) ---")
        return state

    if not settings.BLOG_ID or settings.BLOG_ID == "YOUR_BLOG_ID":
        logger.error("Blogger Blog ID가 설정되지 않았습니다. .env 파일을 확인하세요.")
        state["error_message"] = "Blogger Blog ID가 설정되지 않았습니다. 환경 설정을 확인해주세요."
        logger.info("--- post_to_blogger_node 실행 종료 (Blog ID 없음) ---")
        return state

    try:
        from app.services.blogger_service import post_new_entry
    except ImportError as e:
        logger.error(f"blogger_service 임포트 실패: {e}")
        state["error_message"] = "Blogger 서비스 모듈을 로드할 수 없습니다."
        logger.info("--- post_to_blogger_node 실행 종료 (서비스 임포트 실패) ---")
        return state
        
    try:
        user_id_for_blogger = "default_user" 
        logger.info(f"Blogger 포스팅 시도: Blog ID='{settings.BLOG_ID}', Title='{title_to_post}'")
        posted_data = post_new_entry(
            blog_id=settings.BLOG_ID,
            title=title_to_post,
            content_html=transformed_content,
            user_id=user_id_for_blogger,
            is_draft=False 
        )
        if posted_data and posted_data.get("url"):
            state["posted_url"] = posted_data.get("url")
            logger.info(f"Blogger 포스팅 성공. URL: {state['posted_url']}")
        else:
            logger.error("Blogger 포스팅 후 URL을 가져오지 못했습니다.")
            state["error_message"] = "Blogger 포스팅은 성공했을 수 있으나, 게시글 URL을 가져오지 못했습니다."
    except HTTPException as http_exc:
        logger.error(f"Blogger API 호출 중 HTTP 오류 발생: {http_exc.status_code} - {http_exc.detail}")
        state["error_message"] = f"Blogger 포스팅 실패: {http_exc.detail} (코드: {http_exc.status_code})"
    except Exception as e:
        logger.error(f"Blogger 포스팅 중 예기치 않은 오류 발생: {e}")
        state["error_message"] = f"Blogger 포스팅 중 오류가 발생했습니다: {str(e)}"

    if state.get("blogger_api_call_info") is None:
        state["blogger_api_call_info"] = {} 
    state["blogger_api_call_info"] = {
        "node": "post_to_blogger_node",
        "blog_id": settings.BLOG_ID,
        "title": title_to_post,
        "content_length": len(transformed_content or ""),
        "posted_url": state.get("posted_url"),
        "error": state.get("error_message")
    }
    logger.info("--- post_to_blogger_node 실행 완료 ---")
    return state

def should_post_or_review_node(state: GraphState) -> str:
    """
    처리 옵션에 따라 다음 단계를 결정합니다.
    'auto'인 경우 'post_to_blogger'를, 'review'인 경우 'request_user_review'를 반환합니다.
    """
    logger.info("--- should_post_or_review_node 실행 시작 ---")
    processing_option = state.get("processing_option")
    
    if processing_option == "auto":
        logger.info(f"처리 옵션: '{processing_option}'. 'post_to_blogger_node'로 분기합니다.")
        logger.info("--- should_post_or_review_node 실행 완료 ---")
        return "post_to_blogger"
    elif processing_option == "review":
        logger.info(f"처리 옵션: '{processing_option}'. 'request_user_review_node'로 분기합니다.")
        logger.info("--- should_post_or_review_node 실행 완료 ---")
        return "request_user_review"
    else:
        logger.warning(f"처리 옵션 '{processing_option}'이 유효하지 않습니다. 워크플로우를 종료합니다.")
        state["error_message"] = f"유효하지 않은 처리 옵션입니다: {processing_option}."
        logger.info("--- should_post_or_review_node 실행 완료 (유효하지 않은 옵션) ---")
        return "end"

def should_revise_or_post_final_node(state: GraphState) -> str:
    """
    사용자 검토 후 다음 단계를 결정합니다.
    사용자 의견이 있으면 'revise_content'로, 최종 승인이면 'post_final' (post_to_blogger_node)로 분기합니다.
    is_review_needed가 False로 설정되면 (예: 프론트엔드에서 최종 배포 버튼 클릭 시) 바로 포스팅합니다.
    """
    logger.info("--- should_revise_or_post_final_node 실행 시작 ---")
    user_comment = state.get("user_review_feedback")
    is_review_still_needed = state.get("is_review_needed", True) 

    if not is_review_still_needed: 
        logger.info("최종 배포 승인됨 (is_review_needed=False). 'post_to_blogger_node'로 분기합니다.")
        logger.info("--- should_revise_or_post_final_node 실행 완료 ---")
        return "post_final" 
    elif user_comment: 
        logger.info(f"사용자 의견 있음: '{user_comment}'. 'revise_content_node'로 분기합니다.")
        logger.info("--- should_revise_or_post_final_node 실행 완료 ---")
        return "revise_content"
    else: 
        logger.info("사용자 의견 없음, 최종 배포 아님 (is_review_needed=True). 'request_user_review_node'로 다시 분기 (재검토 유도).")
        logger.info("--- should_revise_or_post_final_node 실행 완료 ---")
        return "request_user_review_again"
