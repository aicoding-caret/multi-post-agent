from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    GEMINI_API_KEY: str = "YOUR_GEMINI_API_KEY_HERE" # .env 파일에서 로드, 기본값 설정
    GOOGLE_CLIENT_ID: str = "YOUR_GOOGLE_CLIENT_ID"
    GOOGLE_CLIENT_SECRET: str = "YOUR_GOOGLE_CLIENT_SECRET"
    BLOG_ID: str = "YOUR_BLOG_ID" # 포스팅할 Blogger 블로그 ID. .env 파일에 실제 ID를 설정해야 합니다.
    # 필요한 경우 추가 설정
    # 예: BLOGGER_API_KEY: str | None = None

    class Config:
        env_file = ".env"
        env_file_encoding = 'utf-8'

@lru_cache()
def get_settings():
    return Settings()

settings = get_settings()
