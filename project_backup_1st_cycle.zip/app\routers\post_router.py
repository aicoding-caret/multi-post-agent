import logging
import json # blogger_service.py의 temp_credentials_storage에 저장하기 위함
from fastapi import APIRouter, Depends, HTTPException, status, Request as FastAPIRequest
from fastapi.responses import HTMLResponse, RedirectResponse
# from fastapi.templating import Jinja2Templates # 나중에 index.html 렌더링 시 필요할 수 있음

# blogger_service에서 필요한 함수들을 import 합니다.
from app.services.blogger_service import get_google_auth_flow, temp_credentials_storage, REDIRECT_URI
# from app.core.config import settings # 필요시 사용

logger = logging.getLogger(__name__)
router = APIRouter(
    tags=["posts", "authentication"] # API 문서용 태그 (posts 추가)
)

# templates = Jinja2Templates(directory="templates") # app/main.py에서 관리하므로 여기서는 주석 처리

# 인증 관련 엔드포인트들은 /auth 접두사를 유지
@router.get("/auth/google", summary="Google OAuth 인증 시작", tags=["authentication"])
async def auth_google():
    """
    Google OAuth 2.0 인증 흐름을 시작하고 사용자를 Google 인증 페이지로 리디렉션합니다.
    """
    try:
        flow = get_google_auth_flow()
        # CSRF 보호를 위해 state 값 생성 및 세션에 저장 (교육용 단순화: state 미사용)
        # authorization_url, state = flow.authorization_url(access_type='offline', prompt='consent')
        authorization_url, _ = flow.authorization_url(access_type='offline', prompt='consent') # state는 현재 사용 안함
        
        logger.info(f"Google 인증 URL 생성: {authorization_url}")
        return RedirectResponse(authorization_url)
    except HTTPException as e:
        logger.error(f"Google 인증 URL 생성 중 오류: {e.detail}")
        # 사용자에게 오류 페이지를 보여주거나, 에러 메시지를 포함한 응답을 반환할 수 있습니다.
        # 여기서는 간단히 에러를 다시 발생시킵니다.
        raise
    except Exception as e:
        logger.error(f"Google 인증 URL 생성 중 예기치 않은 오류: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="인증 서버 연결에 실패했습니다.")

@router.get("/auth/google/callback", summary="Google OAuth 인증 콜백 처리", tags=["authentication"])
async def auth_google_callback(fastapi_request: FastAPIRequest, code: str | None = None, error: str | None = None, state: str | None = None): # state 파라미터 추가
    """
    Google OAuth 2.0 인증 후 콜백을 처리합니다.
    성공 시 액세스 토큰을 요청하고 저장하며, 실패 시 오류를 처리합니다.
    """
    # TODO: CSRF 방지를 위해 state 값 검증 로직 추가
    # if state != fastapi_request.session.pop('oauth_state', None):
    # logger.error("OAuth state 불일치. CSRF 공격 가능성.")
    # return HTMLResponse("<h1>인증 실패</h1><p>잘못된 요청입니다. <a href='/'>홈으로 돌아가기</a></p>", status_code=status.HTTP_400_BAD_REQUEST)

    if error:
        logger.error(f"Google 인증 오류: {error}")
        # TODO: 사용자에게 오류 메시지를 보여주는 페이지로 리디렉션 또는 메시지 전달
        # return RedirectResponse(url="/?auth_error=true") # 예시
        # 임시로 HTML 응답
        return HTMLResponse(f"<h1>인증 실패</h1><p>오류: {error}. <a href='/'>홈으로 돌아가기</a></p>", status_code=status.HTTP_400_BAD_REQUEST)

    if not code:
        logger.error("Google 인증 콜백에 코드가 없습니다.")
        # return RedirectResponse(url="/?auth_error=no_code") # 예시
        return HTMLResponse("<h1>인증 실패</h1><p>인증 코드가 없습니다. <a href='/'>홈으로 돌아가기</a></p>", status_code=status.HTTP_400_BAD_REQUEST)

    try:
        flow = get_google_auth_flow()
        # 콜백 URL이 flow 객체에 설정된 redirect_uri와 일치하는지 확인 (보안 강화)
        # 현재 요청 URL과 flow의 redirect_uri를 비교하는 로직 추가 가능
        # logger.info(f"Current request URL for callback: {str(fastapi_request.url)}")
        # logger.info(f"Flow redirect URI: {flow.redirect_uri}")
        # if str(fastapi_request.url).split('?')[0] != flow.redirect_uri:
        # logger.error("Redirect URI 불일치")
        # raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="잘못된 redirect_uri 입니다.")

        flow.fetch_token(code=code)
        credentials = flow.credentials

        # 교육용 단순화: 'default_user' 키로 임시 저장소에 인증 정보 저장
        # 실제 애플리케이션에서는 사용자별로 관리해야 합니다.
        # credentials 객체를 JSON 직렬화 가능한 형태로 변환하여 저장
        temp_credentials_storage["default_user"] = json.loads(credentials.to_json())
        
        logger.info("Google OAuth 인증 성공 및 토큰 저장 완료 (default_user).")
        # TODO: 인증 성공 메시지를 포함하여 메인 페이지로 리디렉션
        # return RedirectResponse(url="/?auth_success=true", status_code=status.HTTP_302_FOUND)
        # 임시로 HTML 응답. 실제로는 메인 페이지로 리디렉션하고 쿼리 파라미터 등으로 상태 전달
        return HTMLResponse("<h1>인증 성공!</h1><p>Blogger 인증이 완료되었습니다. <a href='/'>메인 페이지로 돌아가기</a></p>")

    except HTTPException as e:
        logger.error(f"토큰 교환 중 HTTP 오류: {e.detail}")
        raise
    except Exception as e:
        logger.error(f"Google 인증 콜백 처리 중 예기치 않은 오류: {e}")
        # return RedirectResponse(url="/?auth_error=callback_failed") # 예시
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"인증 처리 중 오류 발생: {e}")

from app.services import content_service # content_service 임포트
from app.models.post_models import PostCreateRequest, PostResponse, ReviewRequest # ReviewRequest 모델 임포트 추가

@router.post("/process_post", response_model=PostResponse, summary="게시물 처리 요청", tags=["posts"])
async def process_post_endpoint(request: PostCreateRequest, fastapi_request: FastAPIRequest): # fastapi_request 추가 (필요시)
    """
    사용자로부터 제목, 내용, 처리 옵션을 받아 콘텐츠 변환 및 처리를 수행합니다.
    LangGraph 워크플로우를 호출하고 그 결과를 반환합니다.
    """
    logger.info(f"'/process_post' 엔드포인트 호출됨: {request.title}")
    try:
        # content_service.process_content가 PostResponse 객체를 반환하므로,
        # FastAPI는 이를 자동으로 JSON으로 직렬화하여 응답합니다.
        # HTTP 상태 코드는 PostResponse 모델에 직접 넣기보다는,
        # FastAPI의 응답 객체(예: JSONResponse)나 예외 처리를 통해 관리하는 것이 일반적입니다.
        # 여기서는 content_service가 반환하는 PostResponse에 따라 FastAPI가 기본 상태 코드(200 OK)를 사용합니다.
        # 오류 발생 시 content_service 내부에서 PostResponse에 적절한 메시지를 담아 반환하거나,
        # 여기서 HTTP 예외를 발생시켜 FastAPI가 처리하도록 할 수 있습니다.
        
        response_data = await content_service.process_content(request)
        
        # content_service.process_content 함수가 PostResponse 객체를 반환하므로,
        # 해당 객체에 이미 오류 관련 정보(error_detail)가 포함되어 있을 수 있습니다.
        # FastAPI는 response_model에 따라 자동으로 상태 코드를 설정하려고 시도하지만 (주로 200),
        # 오류 상황에 따라 다른 상태 코드를 명시적으로 반환하고 싶다면 여기서 조정이 필요합니다.
        
        if response_data.error_detail:
            # content_service에서 이미 오류를 PostResponse에 담아 반환한 경우
            # 클라이언트에게 전달될 HTTP 상태 코드를 여기서 결정할 수 있습니다.
            # 예를 들어, LangGraph 실행 오류는 500, 입력값 오류는 400 등.
            # 지금은 PostResponse에 담긴 메시지를 그대로 전달하고, FastAPI 기본 상태 코드(200)를 사용합니다.
            # 좀 더 명확한 오류 처리를 위해선, 서비스 계층에서 예외를 발생시키고 라우터에서 처리하는 패턴도 좋습니다.
            logger.warning(f"게시물 처리 중 오류 발생 (서비스에서 처리됨): {response_data.error_detail}")
            # return JSONResponse(content=response_data.model_dump(), status_code=400 or 500 based on error)
            # 우선은 그대로 반환
            return response_data

        return response_data

    except HTTPException:
        # 서비스 계층에서 발생한 HTTP 예외는 그대로 전달
        raise
    except Exception as e:
        logger.exception(f"'/process_post' 엔드포인트 처리 중 예기치 않은 오류 발생: {e}")
        # 예기치 않은 서버 오류 시 500 상태 코드와 함께 PostResponse 형식으로 응답
        return PostResponse(
            message="서버에서 요청을 처리하는 중 예기치 않은 오류가 발생했습니다.",
            error_detail=str(e),
            original_title=request.title,
            original_content=request.content
            # status_code=500 # 모델에 status_code가 없으므로, JSONResponse 사용 필요
        )

# TODO: /submit_review (POST) 엔드포인트는 "검토 후 개시" 흐름 구현 시 추가 예정

@router.post("/submit_review", response_model=PostResponse, summary="사용자 검토 의견 제출 및 최종 배포 요청", tags=["posts"])
async def submit_review_endpoint(request: ReviewRequest, fastapi_request: FastAPIRequest):
    """
    사용자로부터 검토 의견 또는 최종 배포 요청을 받아 처리를 수행합니다.
    content_service.process_review 함수를 호출하고 그 결과를 반환합니다.
    """
    logger.info(f"'/submit_review' 엔드포인트 호출됨. 최종 배포 요청: {request.final_publish}, 의견: {request.comment}")
    try:
        # content_service.process_review 함수가 PostResponse 객체를 반환할 것으로 예상
        response_data = await content_service.process_review(request)
        
        if response_data.error_detail:
            logger.warning(f"검토 의견 처리 중 오류 발생 (서비스에서 처리됨): {response_data.error_detail}")
            # 오류 상황에 따라 적절한 HTTP 상태 코드를 설정하여 JSONResponse로 반환할 수 있으나,
            # 우선은 PostResponse에 담긴 내용을 그대로 반환 (FastAPI 기본 상태 코드 200 OK)
            return response_data
            
        return response_data

    except HTTPException:
        # 서비스 계층에서 발생한 HTTP 예외는 그대로 전달
        raise
    except Exception as e:
        logger.exception(f"'/submit_review' 엔드포인트 처리 중 예기치 않은 오류 발생: {e}")
        # 예기치 않은 서버 오류 시 PostResponse 형식으로 응답 (오류 메시지 포함)
        # 이 경우, 클라이언트가 어떤 요청에 대한 응답인지 알 수 있도록 최소한의 정보라도 포함하는 것이 좋음
        # (예: 원래 요청했던 콘텐츠에 대한 정보 등 - 여기서는 ReviewRequest에 그런 정보가 없으므로 일반 오류로 처리)
        return PostResponse(
            message="서버에서 검토 요청을 처리하는 중 예기치 않은 오류가 발생했습니다.",
            error_detail=str(e)
            # status_code=500 # 모델에 status_code가 없으므로, JSONResponse 사용 필요
        )
