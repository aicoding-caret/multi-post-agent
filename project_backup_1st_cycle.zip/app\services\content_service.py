import logging
from app.models.post_models import PostCreateRequest, PostResponse, ReviewRequest
from app.graph.builder import get_compiled_graph
from app.graph.state import GraphState
from app.core.config import settings
from app.services.blogger_service import temp_credentials_storage

logger = logging.getLogger(__name__)

async def process_content(request: PostCreateRequest) -> PostResponse:
    logger.info(f"콘텐츠 처리 요청 수신: 제목='{request.title}', 옵션='{request.processing_option}'")
    try:
        compiled_graph = get_compiled_graph()
        if not compiled_graph:
            logger.error("LangGraph 컴파일 실패 (process_content)")
            return PostResponse(
                message="서버 내부 오류: AI 워크플로우 실행 불가.",
                error_detail="LangGraph 컴파일 실패",
                original_title=request.title,
                original_content=request.content
            )

        blogger_creds_available = "default_user" in temp_credentials_storage
        # GEMINI_API_KEY로 변경하고, 유효성 검사 로직도 Gemini 키에 맞게 수정
        llm_key_provided = bool(settings.GEMINI_API_KEY and settings.GEMINI_API_KEY != "YOUR_GEMINI_API_KEY_HERE")

        initial_graph_state_input = GraphState(
            original_title=request.title,
            original_content=request.content,
            processing_option=request.processing_option,
            is_review_needed=False, # 초기값
            current_iteration=0, # 초기값
            llm_api_key_provided=llm_key_provided,
            blogger_credentials_available=blogger_creds_available,
            transformed_title=None,
            transformed_content=None,
            user_review_feedback=None,
            posted_url=None,
            error_message=None,
            llm_call_history=[],
            blogger_api_call_info={}
        )
        
        logger.debug(f"LangGraph 실행 전 초기 상태 (process_content): {initial_graph_state_input}")
        final_state = await compiled_graph.ainvoke(initial_graph_state_input, config={"recursion_limit": 20}) # recursion_limit 설정 추가
        logger.debug(f"LangGraph 실행 후 최종 상태 (process_content): {final_state}")

        if final_state.get("error_message"):
            logger.error(f"LangGraph 실행 중 오류 (process_content): {final_state['error_message']}")
            return PostResponse(
                message="콘텐츠 처리 중 오류 발생.",
                error_detail=str(final_state["error_message"]),
                original_title=final_state.get("original_title", request.title),
                original_content=final_state.get("original_content", request.content),
                transformed_title=final_state.get("transformed_title"),
                transformed_content=final_state.get("transformed_content"),
                is_review_needed=final_state.get("is_review_needed", False), # 상태 전달
                current_iteration=final_state.get("current_iteration", 0) # 상태 전달
            )

        return PostResponse(
            message="콘텐츠가 성공적으로 처리되었습니다.",
            original_title=final_state.get("original_title"),
            original_content=final_state.get("original_content"),
            transformed_title=final_state.get("transformed_title"),
            transformed_content=final_state.get("transformed_content"),
            posted_url=final_state.get("posted_url"),
            is_review_needed=final_state.get("is_review_needed", False), # 상태 전달
            current_iteration=final_state.get("current_iteration", 0) # 상태 전달
        )
    except Exception as e:
        logger.exception("process_content 서비스 실행 중 예기치 않은 오류")
        return PostResponse(
            message="서버 내부에서 예기치 않은 오류 발생.",
            error_detail=str(e),
            original_title=request.title,
            original_content=request.content
        )

async def process_review(review_request: ReviewRequest) -> PostResponse:
    logger.info(f"검토 의견 처리 요청 수신: 최종 배포='{review_request.final_publish}', 의견='{review_request.comment}'")
    try:
        compiled_graph = get_compiled_graph()
        if not compiled_graph:
            logger.error("LangGraph 컴파일 실패 (process_review)")
            return PostResponse(
                message="서버 내부 오류: AI 워크플로우 실행 불가.",
                error_detail="LangGraph 컴파일 실패",
                original_title=review_request.original_title, # 요청에서 받은 값 사용
                original_content=review_request.original_content
            )

        # ReviewRequest에서 받은 정보로 GraphState를 정확히 재구성
        review_graph_state_input = GraphState(
            original_title=review_request.original_title,
            original_content=review_request.original_content,
            processing_option=review_request.processing_option, # "review"여야 함
            transformed_title=review_request.transformed_title,
            transformed_content=review_request.transformed_content,
            user_review_feedback=review_request.comment,
            is_review_needed=not review_request.final_publish, # 최종 배포 시 False, 아니면 True
            current_iteration=review_request.current_iteration + 1, # 반복 횟수 증가
            # GEMINI_API_KEY로 변경하고, 유효성 검사 로직도 Gemini 키에 맞게 수정
            llm_key_provided=bool(settings.GEMINI_API_KEY and settings.GEMINI_API_KEY != "YOUR_GEMINI_API_KEY_HERE"),
            blogger_credentials_available="default_user" in temp_credentials_storage,
            posted_url=None, 
            error_message=None,
            llm_call_history=[], # 새 호출이므로 초기화 (또는 이전 기록을 review_request로 받아와 추가)
            blogger_api_call_info={}
        )
        
        logger.debug(f"LangGraph 검토/재실행 전 상태 (process_review): {review_graph_state_input}")

        # should_revise_or_post_final_node 로직을 직접 사용하여 다음 단계를 결정하고 해당 노드 함수를 호출
        from app.graph.nodes import should_revise_or_post_final_node, revise_content_node, post_to_blogger_node
        
        next_step = should_revise_or_post_final_node(review_graph_state_input)
        current_state = review_graph_state_input

        if next_step == "revise_content":
            logger.info("process_review: revise_content_node 직접 호출")
            current_state = revise_content_node(current_state)
            # revise_content_node 실행 후에는 다시 사용자 검토가 필요하므로, is_review_needed=True로 설정됨
            # 이 상태를 그대로 반환하여 UI가 업데이트되도록 함
        elif next_step == "post_final":
            logger.info("process_review: post_to_blogger_node 직접 호출")
            current_state = post_to_blogger_node(current_state)
            current_state["is_review_needed"] = False # 포스팅 후에는 검토 불필요
        elif next_step == "request_user_review_again": # 이 경우는 사용자 의견 없이 최종 배포도 아닐 때
             logger.info("process_review: 사용자 의견 없이 재검토 요청 상태 유지")
             # 특별한 추가 처리 없이 현재 상태(변환된 내용, is_review_needed=True)를 반환
        else: # "end" 또는 예기치 않은 경우
            logger.warning(f"process_review: 예기치 않은 다음 단계: {next_step}")
            current_state["error_message"] = f"검토 처리 중 예기치 않은 상태: {next_step}"

        final_state = current_state
        logger.debug(f"LangGraph 검토/재실행 후 최종 상태 (process_review - 노드 직접 호출 방식): {final_state}")

        if final_state.get("error_message"):
            logger.error(f"LangGraph 검토/재실행 중 오류 (process_review): {final_state['error_message']}")
            return PostResponse(
                message="콘텐츠 검토/수정 중 오류 발생.",
                error_detail=str(final_state["error_message"]),
                original_title=final_state.get("original_title"),
                original_content=final_state.get("original_content"),
                transformed_title=final_state.get("transformed_title"),
                transformed_content=final_state.get("transformed_content"),
                is_review_needed=final_state.get("is_review_needed", True), # 오류 시에도 검토 필요할 수 있음
                current_iteration=final_state.get("current_iteration")
            )

        return PostResponse(
            message="검토 의견이 처리되었거나 최종 배포되었습니다.",
            original_title=final_state.get("original_title"),
            original_content=final_state.get("original_content"),
            transformed_title=final_state.get("transformed_title"),
            transformed_content=final_state.get("transformed_content"),
            posted_url=final_state.get("posted_url"),
            is_review_needed=final_state.get("is_review_needed", False),
            current_iteration=final_state.get("current_iteration")
        )
    except Exception as e:
        logger.exception("process_review 서비스 실행 중 예기치 않은 오류")
        return PostResponse(
            message="서버 내부에서 검토 요청 처리 중 예기치 않은 오류 발생.",
            error_detail=str(e),
            original_title=review_request.original_title, # 요청에서 받은 값 사용
            original_content=review_request.original_content
        )
