from pydantic import BaseModel, Field
from typing import Optional

class PostCreateRequest(BaseModel):
    """
    프론트엔드에서 게시물 생성을 위해 전송하는 데이터 모델
    """
    title: Optional[str] = Field(default=None, title="게시물 제목", max_length=300)
    content: str = Field(..., title="게시물 내용", min_length=1) # 내용은 필수, 최소 길이 1
    processing_option: str = Field(default="auto", title="처리 옵션", pattern="^(auto|review)$") # 'auto' 또는 'review'

class PostResponse(BaseModel):
    """
    서버에서 프론트엔드로 반환하는 응답 모델
    """
    message: str = Field(title="처리 결과 메시지")
    original_title: Optional[str] = None
    original_content: Optional[str] = None
    transformed_title: Optional[str] = None
    transformed_content: Optional[str] = None
    posted_url: Optional[str] = None
    error_detail: Optional[str] = None
    is_review_needed: Optional[bool] = Field(default=False, title="사용자 검토 필요 여부")
    current_iteration: Optional[int] = Field(default=0, title="현재 처리 반복 횟수 (검토 시 증가)")

class ReviewRequest(BaseModel):
    """
    사용자 검토 의견 및 최종 배포 여부를 전달하는 모델.
    GraphState 재구성을 위해 클라이언트가 이전 상태 정보도 함께 전달합니다.
    """
    comment: Optional[str] = Field(default=None, title="사용자 검토 의견")
    final_publish: bool = Field(default=False, title="최종 배포 여부")
    
    # LangGraph 상태 재구성을 위해 클라이언트가 전달하는 이전 상태 정보
    original_title: Optional[str] = Field(default=None, title="원본 제목")
    original_content: str # 원본 내용은 필수
    transformed_title: Optional[str] = Field(default=None, title="이전에 변환된 제목")
    transformed_content: str # 변환된 내용도 필수
    processing_option: str # 현재 처리 옵션 (항상 "review"여야 함)
    current_iteration: int = Field(default=0, title="현재 반복 횟수")
