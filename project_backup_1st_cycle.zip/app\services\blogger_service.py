import logging
import json # 추가
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request # 추가
from fastapi import HTTPException, status
from fastapi.responses import RedirectResponse

from app.core.config import settings

logger = logging.getLogger(__name__)

REDIRECT_URI = "http://localhost:8000/auth/google/callback"
SCOPES = ["https://www.googleapis.com/auth/blogger"]

temp_credentials_storage = {}

def get_blogger_service(user_id: str = "default_user"): # user_id 매개변수 추가
    """
    저장된 인증 정보 또는 새로운 인증 정보를 사용하여 Blogger API 서비스 객체를 반환합니다.
    """
    try:
        credentials_info = temp_credentials_storage.get(user_id)
        
        if not credentials_info:
            logger.warning(f"Blogger API 인증 정보가 없습니다 (사용자: {user_id}). 인증이 필요합니다.")
            return None

        creds = Credentials.from_authorized_user_info(info=credentials_info, scopes=SCOPES)

        if creds and creds.expired and creds.refresh_token:
            logger.info(f"액세스 토큰이 만료되어 갱신합니다 (사용자: {user_id}).")
            try:
                creds.refresh(Request())
                temp_credentials_storage[user_id] = json.loads(creds.to_json())
                logger.info(f"액세스 토큰 갱신 성공 (사용자: {user_id}).")
            except Exception as e:
                logger.error(f"액세스 토큰 갱신 실패 (사용자: {user_id}): {e}")
                # 갱신 실패 시 기존 인증 정보 삭제 또는 다른 처리 필요
                temp_credentials_storage.pop(user_id, None)
                return None

        service = build("blogger", "v3", credentials=creds, cache_discovery=False)
        logger.info(f"Blogger API 서비스 객체 생성 성공 (사용자: {user_id})")
        return service
    except Exception as e:
        logger.error(f"Blogger API 서비스 객체 생성 실패 (사용자: {user_id}): {e}")
        return None

def get_google_auth_flow():
    """Google OAuth 2.0 Flow 객체를 생성하고 반환합니다."""
    try:
        # client_secrets.json 파일을 사용하지 않으므로, client_config를 직접 구성
        client_config = {
            "web": {
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [REDIRECT_URI], # redirect_uri도 client_config에 포함될 수 있음
            }
        }
        flow = Flow.from_client_config(
            client_config=client_config,
            scopes=SCOPES,
            redirect_uri=REDIRECT_URI
        )
        logger.info("Google OAuth Flow 객체 생성 성공")
        return flow
    except Exception as e:
        logger.error(f"Google OAuth Flow 객체 생성 실패: {e}")
        # 실제 운영에서는 여기서 사용자에게 오류를 알리거나, 기본값으로 fallback 하는 등의 처리가 필요할 수 있습니다.
        # 교육용으로는 일단 에러를 발생시키도록 두겠습니다.
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"OAuth Flow 생성 실패: {e}")

def post_new_entry(blog_id: str, title: str, content_html: str, user_id: str = "default_user", is_draft: bool = False):
    """지정된 Blogger 블로그에 새 글을 포스팅합니다."""
    service = get_blogger_service(user_id=user_id)
    if not service:
        logger.error(f"Blogger 서비스 사용 불가 (사용자: {user_id}). 포스팅 실패.")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Blogger 인증이 필요하거나 서비스 초기화에 실패했습니다.")
    
    if not blog_id: # blog_id가 없는 경우를 대비
        logger.error(f"Blog ID가 제공되지 않았습니다 (사용자: {user_id}). 포스팅 실패.")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Blog ID가 필요합니다.")

    try:
        body = {"title": title, "content": content_html}
        # API 문서에 따르면 posts().insert()는 blogId를 path parameter로 받지 않고,
        # service 객체 생성 시 blogId를 지정하거나, 요청 본문에 blogId를 포함해야 할 수 있습니다.
        # Blogger API v3 Python 클라이언트 라이브러리 문서를 다시 확인해야 합니다.
        # 우선은 development-guide.md의 가이드대로 blogId를 파라미터로 전달합니다.
        # 만약 API가 blogId를 insert 메서드의 직접적인 파라미터로 받지 않는다면,
        # service.posts().insert(body=body, isDraft=is_draft, blogId=blog_id).execute() 와 같이 blogId를 명시적으로 전달해야 할 수 있습니다.
        # 또는, Blogger API v3에서는 blogId가 필수 파라미터로 posts().insert()에 전달되어야 합니다.
        
        logger.info(f"Blogger API 호출 시작: blogId='{blog_id}', title='{title}' (사용자: {user_id})")
        post = service.posts().insert(blogId=blog_id, body=body, isDraft=is_draft).execute()
        post_url = post.get('url', 'URL 정보 없음')
        logger.info(f"블로그 '{blog_id}'에 새 글 포스팅 성공: {post_url} (사용자: {user_id})")
        return post
    except Exception as e:
        logger.error(f"블로그 '{blog_id}'에 새 글 포스팅 실패 (사용자: {user_id}): {e}")
        # 에러 메시지에 따라 더 구체적인 HTTP 상태 코드를 반환할 수 있습니다.
        # 예를 들어, 권한 문제(403), 잘못된 요청(400), API 할당량 초과(429) 등
        if hasattr(e, 'resp') and hasattr(e.resp, 'status'):
            if e.resp.status == 401:
                 raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=f"Blogger API 인증 실패: {e}")
            elif e.resp.status == 403:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Blogger API 권한 없음: {e}")
            elif e.resp.status == 404: # 예를 들어 blogId가 잘못된 경우
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Blogger 리소스 찾을 수 없음 (잘못된 Blog ID?): {e}")

        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Blogger 포스팅 중 오류 발생: {e}")
